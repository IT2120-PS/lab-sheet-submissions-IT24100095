
setwd("C:\\Users\\IT24100095\\Desktop\\IT24100095")


# --- PART 1 ---
# Weight data (assumed as laptop bag weights)
weights <- c(
  2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53,
  2.57, 2.85, 2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47,
  2.66, 2.06, 2.41, 2.65, 2.76, 2.43, 2.61, 2.57, 2.73, 2.17,
  2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 2.7, 2.13, 2.75, 2.2
)

# Calculate population mean and standard deviation
population_mean <- mean(weights)
population_sd <- sd(weights)

cat("Population Mean: ", population_mean, "\n")
cat("Population Standard Deviation: ", population_sd, "\n")

# --- PART 2 ---
set.seed(123)  # for reproducibility

sample_means <- numeric(25)
sample_sds <- numeric(25)

for (i in 1:25) {
  sample_i <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
}

# Print sample means and sds
cat("Sample Means:\n")
print(sample_means)
cat("\nSample Standard Deviations:\n")
print(sample_sds)




# --- PART 3 ---

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("Mean of Sample Means: ", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means: ", sd_of_sample_means, "\n")

# Theoretical Standard Error (SE) = population_sd / sqrt(n)
SE_theoretical <- population_sd / sqrt(6)
cat("Theoretical Standard Error: ", SE_theoretical, "\n")


